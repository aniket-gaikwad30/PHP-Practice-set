let cursor = document.querySelector("#cursor");
let form = document.querySelector("form");

// Cursor movement
document.addEventListener("mousemove", (e) => {
  gsap.to(cursor, {
    x: e.clientX,
    y: e.clientY,
    duration: 0.2,
    ease: "power2.out"
  });
});

// Form entry animation
gsap.from("form", {
  opacity: 0,
  scale: 0.6,
  duration: 1.2,
  delay: 0.2,
  ease: "expo.out"
});

// Animate form elements staggered
gsap.from("form label, form input, form button", {
  opacity: 0,
  y: 30,
  duration: 1,
  ease: "power2.out",
  stagger: 0.15,
  delay: 0.5
});

// Cursor grow effect when hovering on form
form.addEventListener("mouseenter", () => {
  gsap.to(cursor, {
    scale: 8,
    backgroundColor: "rgba(0, 217, 255, 0.1)",
    duration: 0.4,
    ease: "expo.out"
  });
});
form.addEventListener("mouseleave", () => {
  gsap.to(cursor, {
    scale: 1,
    backgroundColor: "rgba(0, 217, 255, 0.3)",
    duration: 0.4,
    ease: "expo.out"
  });
});
